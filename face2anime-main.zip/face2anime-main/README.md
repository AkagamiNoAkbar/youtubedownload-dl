<h1 align="center">face2anime</h1>

<p align="center">
<img src="https://raw.githubusercontent.com/Sansekai/face2anime/main/ss.png" width="400"/><br>
<img src="https://raw.githubusercontent.com/Sansekai/face2anime/main/result_example.jpg" width="300"/><br>
From https://h5.tu.qq.com/web/ai-2d/cartoon/index
</p>

## Install
```bash
$ npm install
$ node index.js
```
